<?php

namespace backend\controllers;

use Yii;
use common\models\Notification;
use common\models\NotificationSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * ArticleController implements the CRUD actions for Notification model.
 */
class ArticleController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Notification models.
     * @return mixed
     */
    public function actionIndex()
    {
        $model = new Notification();
        $searchModel = new NotificationSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        
        if ($model->load(Yii::$app->request->post()) && $model->save())
        {
            $model = new Notification(); //reset model
        }

        return $this->render('index', [
            'model' => $model,
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Notification model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Notification model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Notification();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }

    }

    public function actionPush()
    {
        $model = new Notification();

        if ($model->load(Yii::$app->request->post()) && $model->validate()) {
            $gcm = Yii::$app->gcm;
            $push_tokens = [
                'e5MqcKEQvtM:APA91bHeqXARcktUFWfvvy3O_gmBiXCKrXIejyZXJZfMOZX3HLIhDG8UPtGZF4Xh0OY3SHSBYoNYCuehhUL-gPldl4I6KaOMVW-awrmPuSYV-pSQdr4FgDzRG0CJg5oFHsNqB_5QBlpw',
                'fqiU3kz4zOM:APA91bHE4FE4o60RFTUU4TNIk-G0AyqM9NVpMbS-jvAZg9AbuqR3T5QGCLZB8-67N9P4zkXW3-BJSST8z855n45r1WEiQApb8R-JBq4hhOxCohiibFg-R9O8U8ge73kqA0ja1I6XBW8R',
            ];
            $result = $gcm->sendMulti($push_tokens, $model->title,
              [
                'customerProperty' => 1,
              ],
              [
                'timeToLive' => 3
              ]
            );
            return $this->redirect(['index']);
        } else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Updates an existing Notification model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing Notification model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Notification model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Notification the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Notification::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
