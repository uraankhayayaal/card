<?php

namespace frontend\controllers;

use yii\rest\ActiveController;

class CardController extends ActiveController
{
    public $modelClass = 'common\models\Card';
}

?>